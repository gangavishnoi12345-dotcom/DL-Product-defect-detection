# 🛠 Maintainers

This document provides a list of maintainers who are responsible for the overall
codebase, ensuring that the project is moving forward in a coordinated way.
If you have any questions or need assistance, feel free to reach out to any of
the maintainers listed below.

## 👥 Core Maintainers

- **Samet Akcay**
  - GitHub: [@samet-akcay](https://github.com/samet-akcay)
  - Email: samet.akcay@intel.com

- **Rajesh Gangireddy**
  - GitHub: [@rajeshgangireddy](https://github.com/rajeshgangireddy)
  - Email: rajesh.gangireddy@intel.com

- **Ashwin Vaidya**
  - GitHub: [@ashwinvaidya17](https://github.com/ashwinvaidya17)
  - Email: ashwin.vaidya@intel.com

## 🤝 Contributing

We welcome contributions from everyone. If you're interested in helping out, please see our [CONTRIBUTING.md](./CONTRIBUTING.md) file for more information on how to get started. If you're unsure where to begin or have any questions about contributing, feel free to reach out to any of the maintainers listed above.

Here is a list of contributors of Anomalib:

<a href="https://github.com/open-edge-platform/anomalib/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=open-edge-platform/anomalib" alt="Contributors to open-edge-platform/anomalib" />
</a>

## 🙏 Acknowledgements

We'd like to thank all the contributors who have helped shape this project. Your support and contributions are greatly appreciated!

---

This list of maintainers is subject to change as the project evolves. Please check back here for the most up-to-date information.
